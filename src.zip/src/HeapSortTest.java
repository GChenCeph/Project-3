import org.junit.Test;

import student.TestCase;

public class HeapSortTest extends TestCase {

    /**
     * An artificial test to get initial coverage for the
     * main method. Delete or modify this test.
     * @throws Exception 
     */
    @Test
    public void testMain() throws Exception {
        HeapSort dum = new HeapSort();
        assertNotNull(dum);
        String[] str = new String[3];
        str[0] = "sampleBlock1.bin";
        str[1] = "1";
        str[2] = "stat.txt";
        HeapSort.main(str);
        ByteFile file = new ByteFile("sampleBlock1.bin", 1);
        assertTrue(file.isSorted());
        //assertEquals(systemOut().getHistory(), ""); // check that nothing was printed out
    }

}
