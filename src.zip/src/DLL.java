// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those
// who do.
//
// -- guangkai

/**
 * This is DLL class, DLL stands for
 * "Double-linked List".
 * 
 * @author guangkai guangkai@vt.edu
 * @version 1 9/21/2022 7:15 pm
 * @param <Buffer>
 *            Generic Type
 */
public class DLL<T> {

    /**
     * Here classify LinkListedNode as protected.
     */
    protected LinkedNode<T> head;
    private int size;
    private LinkedNode<T> last;
    private LinkedNode<T> first; // ?

    /**
     * Basic structure of SkipList.
     */
    public DLL() {
        head = new LinkedNode<T>(null);
        size = 0;
    }


    /**
     * This will return the first in the list.
     * 
     * @return first if size isn't 0,
     *         null if size is 0
     */
    public LinkedNode<T> getFirst() {

        if (size == 0)
            return null;
        return first;
    }


    /**
     * This will return the last in the list.
     * 
     * @return last if size isn't 0,
     *         null if size is 0
     */
    public LinkedNode<T> getLast() {

        if (size == 0)
            return null;
        return last;
    }


    /**
     * Insert a object to the list.
     * 
     * @param point
     *            as the rec
     */
    public void insert(T elem) {

        LinkedNode<T> node = (LinkedNode<T>)head;
        LinkedNode<T> newNode = (LinkedNode<T>)new LinkedNode<T>(elem);
        LinkedNode<T> update = head.getForward();

        node.setForward(newNode);
        newNode.setForward(update);

        if (update != null) {
            update.setBackward(newNode);
        }
        newNode.setBackward(node);

        size++;
    }


    /**
     * Remove a object to the list.
     * And when call this method, we confirmed
     * that this node we used is the not the first one
     * in the DLL.
     * 
     * @param elem
     *            as the element in the list we want to
     *            remove.
     */
    public void remove(LinkedNode<T> node) {

        if (size != 1) {
            
            LinkedNode<T> temp = node.getBackward();
            LinkedNode<T> next = node.getForward();
            LinkedNode<T> headNext = head.getForward();
            if (next != null) {

                temp.setForward(next);
                next.setBackward(temp);
            }
            else {

                temp.setForward(null);
                last = temp;
            }
            head.setForward(node);

            node.setForward(headNext);
            node.setBackward(head);

            headNext.setBackward(node);
        }
    }
}
