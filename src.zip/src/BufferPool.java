import java.io.IOException;
import java.io.RandomAccessFile;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those
// who do.
//
// -- guangkai

/**
 * This is BufferPool class.
 * 
 * @author guangkai
 * @version 1 10/14/2022 2:19 pm
 */
public class BufferPool {

// /**
// * Here classify LinkListedNode as protected.
// */
// protected Buffer head;
    private RandomAccessFile file;
    // private int block;
    private DLL<Buffer> pool;
    public int size = 0;
    public int maxSize = 0;
    Statistic bPStat;

    /**
     * This is the constructor of BufferPool.
     * 
     * @param inputFile
     *            use when need to get new block.
     * @param numberOfBuffer
     *            as the max size of buffers.
     * @param stat
     * @throws IOException
     *             if file is not found.
     */
    public BufferPool(
        RandomAccessFile inputFile,
        int numberOfBuffer,
        Statistic stat)
        throws IOException {

        // head = new Buffer();
        file = inputFile;
        // block = (int)file.length() / 4096;
        maxSize = numberOfBuffer;
        pool = new DLL<Buffer>();
        bPStat = stat;
    }


    /**
     * This will give the maxHeap the rec it requested.
     * 
     * @throws IOException
     */
    public Record giveRec(int recPos) throws IOException {

        LinkedNode<Buffer> target = pool.head;
        Record requested;
        int count = 0;
        if (size != 0) {
            
            // First see if the required pos is in current
            // bufferPool
            while (target.getForward() != null) {

                target = target.getForward();

                if (target.getBuffer().isIn(recPos)) {

                    requested = target.getBuffer().giveRecord(recPos);
                    if (count != 1) {

                        pool.remove((LinkedNode<Buffer>)target);
                    }
                    bPStat.cacheHitIncrease();
                    return requested;
                }
                count++;
            }

            // If not, create new buffer which:
            // first seek the position in file
            // second read that block and use it to create a new buffer
            // last put that new buffer in the DLL and give MaxHeap the pos it
            // required.
            bPStat.cacheMissIncrease();
            if (size == maxSize) {

                target.getBuffer().fileWrite();
                bPStat.diskWriteIncrease();
            }
            target.getBuffer().fileRead(recPos);
            bPStat.diskReadIncrease();
            pool.remove((LinkedNode<Buffer>)target);
            requested = target.getBuffer().giveRecord(recPos);

            return requested;
        }
        else {
            
            int blockPos = recPos / 1024;
            Buffer newBuffer = new Buffer(file, blockPos, bPStat, recPos);
            LinkedNode<Buffer> newNode = new LinkedNode<Buffer>(newBuffer);
            pool.insert(newBuffer);
            requested = newNode.getBuffer().giveRecord(recPos);
            size++;
        }
        return requested;
    }


//    /**
//     * This is swap()
//     * 
//     * @throws IOException
//     */
//    public void swap(int recPos1, int recPos2) throws IOException {
//
//        Record rec1 = null;
//        Record rec2 = null;
//
//        rec1 = giveRec(recPos1);
//        rec2 = giveRec(recPos2);
//
//        Record temp = rec1;
//        rec1.setTo(rec2);
//        rec2.setTo(temp);
//    }


    /**
     * This is flush() method.
     * 
     * @throws IOException
     */
    public void flush() throws IOException {

        LinkedNode<Buffer> target = pool.head;
        while (target.getForward() != null) {

            target = target.getForward();
            target.getBuffer().flush();
            bPStat.diskWriteIncrease();
        }
    }
}
