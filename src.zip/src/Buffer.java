import java.io.IOException;
import java.io.RandomAccessFile;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those
// who do.
//
// -- guangkai

/**
 * This is Buffer class.
 * 
 * @author guangkai
 * @version 1 10/14/2022 2:29 pm
 */
public class Buffer {
    
    
    //private LinkedNode<Buffer> node;
    private RandomAccessFile file;
    private boolean dirty;
    private Record[] rec = new Record[1024];
    private byte[] rec2 = new byte[4096];
    private int position;
    private int block;
    private int firstRec;
    Statistic bStat;

    
    /**
     * This hold value.
     * 
     * @param obj as the record.
     * @throws IOException 
     */
    public Buffer(RandomAccessFile inputFile, int blockNumber, Statistic stat, int recPos) throws IOException {
        
        file = inputFile;
        block = blockNumber;
        position = blockNumber * 4096;
        firstRec = blockNumber * 1024;
        dirty = false;
        bStat = stat;
        fileRead(recPos);
        write(rec2);
    }
    
    
    /**
     * This will tell if the requested location from maxHeap
     * is in this buffer.
     * 
     * @param requestedPos is the location of the record in
     *        the file.
     */
    public boolean isIn(int requestedPos) {
        
        if (requestedPos > position && requestedPos < position + 4096)
            return true;
        return false;
    }
    
    
    /**
     * This is getPosition() method.
     * 
     * @return rec.value as the element
     */
    public int getPosition() {
        
        return position;
    }
    
    
    /**
     * This will return block.
     */
    public int getBlock() {
        
        return block;
    }
    
    
    /**
     * This will give a record.
     */
    public Record giveRecord(int recPos) {
        
        Record target = rec[recPos - firstRec];
        bStat.cacheHitIncrease();
        return target;
    }
    
    
//    /**
//     * get data from buffer.
//     *
//     * @return rec as output
//     */
//    public Record read(int pos) {
//        
//        return rec[pos];
//    }
    
    
    /**
     * set data.
     *
     * @param newData as the input.
     */
    public void write(byte[] newData) {
        
        rec = Record.toRecArray(newData);
        dirty = true;
    }
    
    
    /**
     * read from file by a specified offset.
     * Will use to renew the buffer.
     *
     * @throws IOException if nothing
     */
    public void fileRead(int recPos) throws IOException {

        fileWrite();
        int blockPos = (recPos * 4) / 4096;
        position = blockPos * 4096;
        file.seek(position);
        
        file.read(rec2);
        rec = Record.toRecArray(rec2);
        bStat.diskReadIncrease();;
    }
    
    
    /**
     * write data back to file.
     *
     * @throws IOException if nothing
     */
    public void fileWrite() throws IOException {
        
        if (dirty) {
            
            file.seek(position);
            file.write(rec2, position, 4096);
            dirty = false;
            bStat.diskWriteIncrease();
        }
    }
    
    /**
     * This will flush this buffer back to
     * the file.
     * @throws IOException if file not exist.
     */
    public void flush() throws IOException {
        
        fileWrite();
        bStat.diskWriteIncrease();
    }
}
