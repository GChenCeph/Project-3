import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

// Remember to remove the package from all files!

// HONOR CODE GOES HERE


/**
 * External HeapsSort starter kit.  
 * 
 * @author {your PID}
 */
public class HeapSort {

    /**
     * This is the entry point of the application
     * 
     * @param args
     *            Command line arguments
     * @throws Exception 
     */
    public static void main(String[] args) throws Exception {
        
        // Look at the spec to see what arguments are used for!
        //String filename = args[0].trim();
        long starting, ending;
        starting = System.currentTimeMillis();
        
        Statistic stat = new Statistic();
        
        File inputFile = new File(args[0]);
        String number = args[1];
        int numberOfBuffer = Integer.parseInt(number);
        
        RandomAccessFile file = new RandomAccessFile(inputFile, "rw");
        BufferPool pool = new BufferPool(file, numberOfBuffer, stat);
        File statFile = new File(args[2]);
        
        int numberOfRecord = (int)file.length() / 4;
        MaxHeap heap = new MaxHeap(numberOfRecord, pool, stat);
        pool.flush();
        
        ending = System.currentTimeMillis();
        long Elapsed = ending - starting;
    }
}
